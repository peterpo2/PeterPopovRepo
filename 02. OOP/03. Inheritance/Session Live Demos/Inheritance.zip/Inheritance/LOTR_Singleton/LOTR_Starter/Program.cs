﻿using System;
using System.IO;
using System.Diagnostics;

namespace LOTR_Starter
{
    internal class Program
    {
        // Demo To Do List:  Today we will take an implemented class and apply the Singleton Design Pattern:
        // - show a class diagram (UML) for the TheOneRing class
        // - change class to Sealed, change contstructor accessor to Private
        // - Add Static instance of object, create a ForgedIn method
        // - Test:  Can we create more than one ring?
        // - A ring takes time to forge (5 seconds)..  Could this create problems?  How do we solve for that?
        // - OPTIONAL research for solution:  Design Patterns, Singleton Pattern, static keyword
        // - https://dofactory.com/net/design-patterns
        static void Main(string[] args)
        {
            WorkWithRingsOfPower();

            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
        private static void WorkWithRingsOfPower()
        {
            Console.WriteLine("Creating a Ring of Power!...");
            TheOneRing myRingOfPower = new TheOneRing();
            Console.WriteLine("..A Ring of Power has been created!");

            Console.WriteLine($"Ring Bearer: {myRingOfPower.RingBearer}");
            Console.WriteLine($"Nickname: {myRingOfPower.Nickname}"); 
            Console.WriteLine($"Inscription: {myRingOfPower.Inscription}");
            Console.WriteLine($"Forged In: {myRingOfPower.ForgedIn}");

            Console.WriteLine();
            Console.WriteLine(myRingOfPower.ChangeRingBearer("Isildur"));
            Console.WriteLine();
            Console.WriteLine(myRingOfPower.ChangeRingBearer("Gollum"));
            Console.WriteLine();
            Console.WriteLine(myRingOfPower.ChangeRingBearer("Bilbo"));
            Console.WriteLine();
            Console.WriteLine(myRingOfPower.ChangeRingBearer("Frodo"));

            myRingOfPower.Show();

            // What happens if we try to create multiple rings?
            Console.WriteLine();
            Console.WriteLine("Creating the a second Ring of Power!...");
            TheOneRing myRingOfPower2 = new TheOneRing();
            Console.WriteLine("Creating the a third Ring of Power!...");
            TheOneRing myRingOfPower3 = new TheOneRing();

            // Is there one ring?  Or multiple rings?
            if (Object.ReferenceEquals(myRingOfPower2, myRingOfPower3))
            {
                Console.WriteLine("...These are the same ring of power!");
            }
            else
            {
                Console.WriteLine("...These are different rings of power?!?");
            }
        }
    }
}
