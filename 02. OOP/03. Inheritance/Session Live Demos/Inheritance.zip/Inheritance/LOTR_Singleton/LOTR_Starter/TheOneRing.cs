﻿using System.Threading;
using System.Diagnostics;
using System.IO;
using System;

namespace LOTR_Starter
{
    public class TheOneRing
    {
        private string ringBearer;
        private string imagePath;
        private string nickname;
        private string inscription;
        private string forgedIn;
        private bool isRingForged;

        public TheOneRing()
        {
            this.isRingForged = false;
            this.imagePath = @"\Images\TheOneRing.jpg";
            this.inscription = "One Ring to rule them all, One Ring to find them, One Ring to bring them all and in the darkness bind them.";
            this.ringBearer = "Sauron";
            this.forgedIn = "Orodruin Fires (Mount Doom)";
            this.nickname = "My Precioussss";

            ForgeTheRing();
        }

        #region Properties
        public string ForgedIn
        {
            get { return forgedIn; }
        }
        public string Inscription
        {
            get
            {
                // Conditions under which the inscription appears?
                return inscription;
            }
        }
        public string Nickname
        {
            get { return nickname; }
            set { nickname = value; }
        }
        public string RingBearer
        {
            get { return ringBearer; }
        }
        #endregion Properties

        #region Methods
        private void ForgeTheRing()
        {
            // The One Ring takes time to forge!
            Thread.Sleep(5000);
            this.isRingForged = true;
            // throw new NotImplementedException();
        }
        public string ChangeRingBearer(string owner)
        {
            // There might be some conditions before granting ownership!
            this.ringBearer = owner;
            string message = $"{ringBearer} now has the One Ring of Power!";
            return message;
        }
        public void Show()
        {
            // Show the ring!           
            string projectDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName; // This will get the current PROJECT directory
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = projectDirectory + this.imagePath;
            info.UseShellExecute = true;
            info.CreateNoWindow = true;
            info.Verb = string.Empty;
            Process.Start(info);
        }
        #endregion Methods
    }
}