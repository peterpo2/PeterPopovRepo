﻿using System;

namespace LOTR_Solution
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WorkWithTheOneRing();

            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
        private static void WorkWithTheOneRing()
        {
            Console.WriteLine("Creating the The One Ring to Rule Them All!...");
            // Note:  "New" not required...
            TheOneRing Ring1 = TheOneRing.Forge();
            Console.WriteLine("..A Ring of Power has been created!");

            Console.WriteLine();
            Console.WriteLine(Ring1.ChangeRingBearer("Isildur"));
            Console.WriteLine();
            Console.WriteLine(Ring1.ChangeRingBearer("Gollum"));
            Console.WriteLine();
            Console.WriteLine(Ring1.ChangeRingBearer("Bilbo"));
            Console.WriteLine();
            Console.WriteLine(Ring1.ChangeRingBearer("Frodo"));

            // What happens when we try to create another?
            Console.WriteLine("Attempt to forge another One Ring to Rule Them All?...");
            TheOneRing Ring2 = TheOneRing.Forge();

            // Test to see if they are the same or different rings
            if (Object.ReferenceEquals(Ring1, Ring2))
            {
                Console.WriteLine("...There is only ONE True Ring to rule them all!");
            }
            Ring1.Show();

            // Set the owner of ring ONE
            Ring1.RingBearer = "Meeeee!";
            // Check the owner of ring TWO - Sauron?  Or me?
            Console.WriteLine($"Current Ring Bearer: {Ring2.RingBearer}");
        }

    }
}
