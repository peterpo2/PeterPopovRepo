﻿using System;
using System.Diagnostics;
using System.IO;
using System.Collections.Generic;

namespace Duck_Starter
{
    internal class Program
    {
        // Demo To Do List:  Today we will resolve design issues and apply Inheritance principles:
        // - show a class diagram (UML) for the Duck class
        // - implement a DuckType enum.  
        // - Move property defaults to private variable declarations
        // - Add property for Duck Type
        // - Mark methods so that they can be overridden in derived classes
        // - Create inherited classes for DabblingDuck, DivingDuck and RubberDuck
        // - Implement necessary overridden methods for inherited classes
        // - Remove "hard coded" checks for Rubber duck species and move to RubberDuck class
        // - Ensure Descriptions are different / appropriate for different types of ducks.
        // - Design challenge:  Not all ducks have all types of behaviour - rubber ducks cannot fly.
        // - Design Patterns Part 2:  Strategy pattern to implement behaviours such as fly.  However that will require
        //   that we cover more concepts first - abstraction, interfaces, etc.

        static void Main(string[] args)
        {
            WorkWithDucks();

            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
        private static void WorkWithDucks()
        {
            List<Duck> myDucks = new List<Duck>();

            Duck myDuck = new Duck();
            myDucks.Add(myDuck);

            Duck myDuck2 = new Duck();
            myDuck2.Species = DuckSpecies.Mallard;
            myDuck2.Name = "Captain Canada";
            myDuck2.ImagePath = @"\Images\mallard.jpg";
            myDucks.Add(myDuck2);

            foreach (Duck duck in myDucks)
            {
                Console.WriteLine();
                Console.WriteLine("I'm going to show you a {0} Duck named {1}!", duck.Species.ToString(), duck.Name);
                Console.WriteLine("Tracker Id: {0}", duck.TrackerId.ToString());
                // Show me the duck!           
                duck.Show();
            }
        }

    }
}
