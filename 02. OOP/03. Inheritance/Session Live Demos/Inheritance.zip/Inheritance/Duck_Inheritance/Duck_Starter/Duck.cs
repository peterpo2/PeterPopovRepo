﻿using System;
using System.Diagnostics;
using System.IO;
using System.Collections.Generic;
using System.Text;

namespace Duck_Starter
{
    public enum DuckSpecies
    {
        Generic,
        Mallard,
        WoodDuck,
        Canvasback,
        HoodedMerganser,
        Rubber
    }
    public class Duck
    {
        private string name;
        private string imagePath;
        private Guid trackerId = Guid.NewGuid();
        private DuckSpecies species;
        public Duck()
        {
            this.Name = "A Duck";
            this.Species = DuckSpecies.Generic;
            this.ImagePath = @"\Images\generic.jpg"; ;
        }
        public Duck(string name, DuckSpecies species, string imagePath)
        {
            this.Name = name;
            this.Species = species;
            this.ImagePath = imagePath;
        }
        #region Properties
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                if (value.Length < 2 || value.Length > 25)
                {
                    throw new ArgumentException("Name must be between 2 and 25 characters.");
                }
                else
                {
                    this.name = value;
                }
            }
        }
        public DuckSpecies Species
        {
            get
            {
                return this.species;
            }
            set
            {
                this.species = value;
            }
        }
        public Guid TrackerId
        {
            get
            {
                return this.trackerId;
            }
        }
        public string ImagePath
        {
            set
            {
                imagePath = value;
            }
        }
        #endregion Properties

        #region Methods
        public string Quack()
        {
            string quack;
            if (this.species == DuckSpecies.Rubber)
            {
                quack = "Squeak! Squeak!!";
            }
            else
            {
                quack = "Quack! Quack!!";
            }
            return quack;
        }
        public string Swim()
        {
            string swim;
            if (this.species == DuckSpecies.Rubber)
            {
                swim = "Float... float.";
            }
            else
            {
                swim = "Paddle! Paddle!!";
            }
            return swim;
        }
        public string Fly()
        {
            string fly;
            if (this.species == DuckSpecies.Rubber)
            {
                fly = "Fly? You are going to have to toss me...";
            }
            else
            {
                fly = "Fly! Fly!!";
            }
            return fly;
        }
        public void Show()
        {
            string projectDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName; // This will get the current PROJECT directory
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = projectDirectory + this.imagePath;
            info.UseShellExecute = true;
            info.CreateNoWindow = true;
            info.Verb = string.Empty; Process.Start(info);
        }
        #endregion Methods
    }
}
