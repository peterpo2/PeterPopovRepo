﻿using System;
using System.Collections.Generic;

namespace Duck_Solution
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WorkWithDuckInheritance();

            Console.WriteLine();
            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }

        private static void WorkWithDuckInheritance()
        {
            List<Duck> myDucks = new List<Duck>();

            var myDuck2 = new DabblingDuck("Captain Canada", DuckType.Dabbling, DuckSpecies.Mallard, @"\Images\mallard.jpg");
            myDucks.Add(myDuck2);

            if (myDuck2 is DabblingDuck)
            {
                Console.WriteLine($"{myDuck2.Species.ToString()} is a type of dabbling duck! (derived class)");
            }
            if (!(myDuck2 is DivingDuck))
            {
                Console.WriteLine($"{myDuck2.Species.ToString()} is NOT a diving duck! (derived class)");
            }
            if (myDuck2 is Duck)
            {
                Console.WriteLine($"A {myDuck2.Type.ToString()} duck IS A type of Duck! (inheritance)");
            }

            myDucks.Add(new DivingDuck("Hoodwink", DuckType.Diving, DuckSpecies.HoodedMerganser, @"\Images\HoodedMerganser.jpg"));
            myDucks.Add(new RubberDuck("Squeaky", DuckType.Rubber, DuckSpecies.Rubber, @"\Images\rubber.jpg"));

            foreach (Duck duck in myDucks)
            {
                Console.WriteLine();
                Console.WriteLine("I'm going to show you a {0} Duck named {1}!", duck.Species.ToString(), duck.Name);
                Console.WriteLine("Duck Type: {0}", duck.Type.ToString());
                Console.WriteLine("Tracker Id: {0}", duck.TrackerId.ToString());
                Console.WriteLine(duck.Quack());
                Console.WriteLine(duck.Swim());
                Console.WriteLine(duck.Fly());
                duck.Show();
            }
        }
    }

}

