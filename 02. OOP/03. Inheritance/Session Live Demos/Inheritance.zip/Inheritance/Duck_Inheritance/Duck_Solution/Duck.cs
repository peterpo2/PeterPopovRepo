﻿using System;
using System.IO;
using System.Diagnostics;

namespace Duck_Solution
{
    public enum DuckSpecies
    {
        Generic,
        Mallard,
        WoodDuck,
        Canvasback,
        HoodedMerganser,
        Rubber
    }
    public enum DuckType
    {
        Generic,
        Dabbling,
        Diving,
        Rubber
    }
    public class Duck
    {
        private string name = "A Duck";
        private string imagePath = @"\Images\generic.jpg";
        private Guid trackerId = Guid.NewGuid();
        private DuckSpecies species = DuckSpecies.Generic;
        private DuckType type = DuckType.Generic;

        public Duck(string name, DuckType type, DuckSpecies species, string imagePath)
        {
            this.Name = name;
            this.Species = species;
            this.Type = type;
            this.ImagePath = imagePath;
        }
        #region Properties
        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }
        public DuckType Type
        {
            get
            {
                return type;
            }
            set
            {
                type = value;
            }
        }
        public DuckSpecies Species
        {
            get
            {
                return this.species;
            }
            set
            {
                this.species = value;
            }
        }
        public Guid TrackerId
        {
            get
            {
                return this.trackerId;
            }
        }
        public string ImagePath
        {
            set
            {
                imagePath = value;
            }
        }
        #endregion Properties

        #region Methods
        public virtual string Quack()
        {
            return "Quack! Quack!!";
        }
        public virtual string Swim()
        {
            return "Paddle! Paddle!!";
        }
        public virtual string Fly()
        {
            return "Fly! Fly!!";
        }
        public void Show()
        {
            string projectDirectory = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName; // This will get the current PROJECT directory
            ProcessStartInfo info = new ProcessStartInfo();
            info.FileName = projectDirectory + this.imagePath;
            info.UseShellExecute = true;
            info.CreateNoWindow = true;
            info.Verb = string.Empty; Process.Start(info);
        }
        #endregion Methods
    }
    public class Goose : Duck
    {
        public string SomeNewGooseProperty { get; set; }
        public string whatever { get; set; }
        public Goose(string name, DuckType type, DuckSpecies species, string imagePath, string temper) : base(name, type, species, imagePath)
        {
            // if i had some more code to initialize a goose....
            SomeNewGooseProperty = "something";
            whatever = temper;
        }

        public string somegoosemethod()
        {
            return "goose method";
        }
        public override string Quack()
        {
            base.Quack();
            // then have my own code here

            return "Honk! Honk!";
        }
    }


    public class DabblingDuck : Duck
    {
         public DabblingDuck(string name, DuckType type, DuckSpecies species, string imagePath) : base(name, type, species, imagePath)
        {
        }

    }
    public class DivingDuck : Duck
    {
        public DivingDuck(string name, DuckType type, DuckSpecies species, string imagePath) : base( name, type, species, imagePath) 
        {
        }

        public override string Swim()
        {
            // do stuff before
            string baseSwim = base.Swim();
            // do stuff after
            return "Dive! Dive!!";
        }

    }
    public class RubberDuck : Duck
    {
        public RubberDuck(string name, DuckType type, DuckSpecies species, string imagePath) : base(name, type, species, imagePath) 
        {
        }

        public override string Quack()
        {
            return "Squeak! Squeak!!";
        }
        public override string Swim()
        {
            return "Float... float.";
        }
        public override string Fly()
        {
            return "Fly? You are going to have to toss me...";
        }
    }

    public class myDuck
    {
        // properties , methods
    }

}
