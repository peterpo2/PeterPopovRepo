﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace ShapesDemo
{
    public abstract class Shape2D : IComparable<Shape2D>
    {
        public abstract double CalculateArea();
        public int CompareTo(Shape2D other)
        {
            if (this.CalculateArea() > other.CalculateArea())
            {
                return 1;
            }
            else if (this.CalculateArea() < other.CalculateArea())
            {
                return -1;
            }
            else
            {
                return 0;
            }
        }

        protected string AProtectedMethod()
        {
            return "You called the Protected Method!";
        }
        internal string AnInternalMethod()
        {
            return "You called the Internal Method!";
        }
        protected internal string AProtectedInternalMethod()
        {
            return "You called the Protected Internal Method!";
        }
        private protected string APrivateProtectedMethod()
        {
            return "You called the Private Protected Method!";
        }


    }

    public class Circle : Shape2D, ICloneable, IEquatable<Circle>
    {
        private int radius;

        public Circle(int radius)
        {
            this.radius = radius;
        }

        public int Radius
        {
            get { return radius; }
            set { radius = value; }
        }

        public override double CalculateArea()
        {
            return radius * radius * Math.PI;
        }

        public object Clone()
        {
            return this.MemberwiseClone();
        }

        public bool Equals(Circle other)
        {
            return (this.Radius.Equals(other.Radius));
        }

        #region Testing Access Modifiers
        public void TestAccessModifiers()
        {
            Console.WriteLine();
            Console.WriteLine("Testing Access Modifiers from Derived Class...");
            Console.WriteLine($"{AProtectedMethod()}");
            Console.WriteLine($"{AnInternalMethod()}");
            Console.WriteLine($"{AProtectedInternalMethod()}");
            Console.WriteLine($"{APrivateProtectedMethod()}");
        }
        #endregion
    }

    public class Rectangle : Shape2D
    {
        private int width;
        private int hieght;

        public int Width
        {
            get { return width; }
            set { width = value; }
        }
        public int Height
        {
            get { return hieght; }
            set { hieght = value; }
        }

        public Rectangle(int width, int height)
        {
            this.Width = width;
            this.Height = height;
        }
        public override double CalculateArea()
        {
            return width * Height;
        }
    }

    public class Square : Rectangle
    {
        private int length;

        public int Length
        {
            get { return length; }
            set { length = value; }
        }

        public Square(int length) : base(length, length)
        {
            this.Length = length;
        }
    }
}
