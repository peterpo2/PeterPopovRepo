﻿using System;
using System.Collections.Generic;
using MoreShapes;

namespace ShapesDemo
{
    internal class Program
    {
        static void Main(string[] args)
        {
            #region Comparing strings
            Console.WriteLine();
            Console.WriteLine("Comparing strings:");
            Console.WriteLine();
            string s1 = "test";
            string s2 = "test";
            string s3 = "test1".Substring(0, 4);
            object s4 = s3; // Note: Object!

            Console.WriteLine($"s1 & s2 - RefEquals: {object.ReferenceEquals(s1, s2)},  ==:  {s1 == s2},  .Equals:  {s1.Equals(s2)}");
            Console.WriteLine($"s1 & s3 - RefEquals: {object.ReferenceEquals(s1, s3)}, ==:  {s1 == s3},  .Equals:  {s1.Equals(s3)}");
            Console.WriteLine($"s1 & s4 - RefEquals: {object.ReferenceEquals(s1, s4)}, ==:  {s1 == s4}, .Equals:  {s1.Equals(s4)}");

            Console.WriteLine();
            Console.WriteLine("Press any key to continue....");
            Console.ReadKey();
            #endregion

            #region Comparing Circles
            Console.WriteLine();
            Console.WriteLine("Comparing Circle Objects:");
            Console.WriteLine();
            Circle myCircle1 = new Circle(7);
            Console.WriteLine($"The area of a circle with radius {myCircle1.Radius} is {myCircle1.CalculateArea()}");

            Circle myCircle2 = new Circle(1);
            Circle myCircle3 = (Circle) myCircle2.Clone();
            Circle myCircle4 = new Circle(5);
            Circle myCircle5 = new Circle(5);
            Circle myCircle6 = myCircle2;

            // Compare circle 4 and 5 equality
            Console.WriteLine();
            Console.WriteLine("Test using == operator...");
            if (myCircle4 == myCircle5)
            {
                Console.WriteLine("Circle4 and Circle5 are equal!");
            }
            else
            {
                //Note they are different because == uses object.ReferenceEquals
                Console.WriteLine("Circle4 and Circle5 are different!");
            }

            Console.WriteLine();
            Console.WriteLine("Test using object.Equals method...");
            if (myCircle4.Equals(myCircle5))
            {
                Console.WriteLine("Circle4 and Circle5 are equal!");
            }
            else
            {
                Console.WriteLine("Circle4 and Circle5 are different!");
            }

            // Compare circle 2 and 3 equality
            Console.WriteLine();
            Console.WriteLine("Test using == operator...");
            if (myCircle2 == myCircle3)
            {
                Console.WriteLine("Circle2 and Circle3 are equal!");
            }
            else
            {
                Console.WriteLine("Circle2 and Circle3 are different!");
            }

            Console.WriteLine();
            Console.WriteLine("Test using object.Equals method...");
            if (myCircle2.Equals(myCircle3))
            {
                Console.WriteLine("Circle2 and Circle3 are equal!");
            }
            else
            {
                Console.WriteLine("Circle2 and Circle3 are different!");
            }

            // Compare circle 2 and 6
            Console.WriteLine();
            Console.WriteLine("Test using == operator...");
            if (myCircle2 == myCircle6)
            {
                Console.WriteLine("Circle2 and Circle6 are equal!");
            }
            else
            {
                Console.WriteLine("Circle2 and Circle6 are different!");
            }

            Console.WriteLine();
            Console.WriteLine("Test using object.Equals method...");
            if (myCircle2.Equals(myCircle6))
            {
                Console.WriteLine("Circle2 and Circle6 are equal!");
            }
            else
            {
                Console.WriteLine("Circle2 and Circle6 are different!");
            }

            Console.WriteLine();
            Console.WriteLine("Press any key to continue....");
            Console.ReadKey();
            #endregion

            #region Circle sorting
            Console.WriteLine();
            Console.WriteLine("Circles and Sorting:");
            Console.WriteLine();

            List<Circle> myCircles = new List<Circle>();
            myCircles.Add(myCircle1);
            myCircles.Add(myCircle2);
            myCircles.Add(myCircle3);
            myCircles.Add(myCircle4);
            myCircles.Add(myCircle5);
            myCircles.Add(myCircle6);

            Console.WriteLine("Unsorted Circles List:");
            foreach (Circle circle in myCircles)
            {
                Console.WriteLine($"Circle with radius {circle.Radius} and area {circle.CalculateArea()}");
            }

            myCircles.Sort();

            Console.WriteLine();
            Console.WriteLine("Sorted Circles List:");
            foreach (Circle circle in myCircles)
            {
                Console.WriteLine($"Circle with radius {circle.Radius} and area {circle.CalculateArea()}");
            }

            Console.WriteLine();
            Console.WriteLine("Press any key to continue....");
            Console.ReadKey();
            #endregion

            #region More fun with shapes...
            Rectangle myRectangle = new Rectangle(8, 2);
            Square mySquare = new Square(4);

            Console.WriteLine();
            Console.WriteLine("Rectangle and Square:");
            Console.WriteLine();
            Console.WriteLine($"Area of Rectangle is {myRectangle.CalculateArea()}");
            Console.WriteLine($"Area of Square is    {mySquare.CalculateArea()}");
            #endregion

            #region Test Access Modifiers
            Console.WriteLine();
            Console.WriteLine("Main/Circle: Testing Access Modifiers from class located in another assembly...");
            //Console.WriteLine($"{myCircle1.AProtectedMethod()}");
            //Console.WriteLine($"{myCircle1.AnInternalMethod()}");
            //Console.WriteLine($"{myCircle1.AProtectedInternalMethod()}");
            //Console.WriteLine($"{myCircle1.APrivateProtectedMethod()}");

            myCircle1.TestAccessModifiers();

            // Shapes in another assembly...
            Triangle myTriangle = new Triangle();
            myTriangle.TestAccessModifiers();
            Sphere mySphere = new Sphere();
            mySphere.TestAccessModifiers();
            Cone myCone = new Cone();
            myCone.TestAccessModifiers();
            #endregion

            Console.WriteLine();
            Console.WriteLine("Press any key to exit....");
            Console.ReadKey();
        }
    }
}
