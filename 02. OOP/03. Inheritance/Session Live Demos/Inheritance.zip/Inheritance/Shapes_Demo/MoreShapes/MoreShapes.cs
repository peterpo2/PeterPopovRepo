﻿using System;
// Add a project reference (dependency) to the MoreShapes project
using ShapesDemo;

namespace MoreShapes
{
    public class Triangle : Shape2D
    {
        public override double CalculateArea()
        {
            throw new NotImplementedException();
        }
        #region Testing Access Modifiers
        public void TestAccessModifiers()
        {
            Console.WriteLine();
            Console.WriteLine("Testing Access Modifiers from Derived Class in another assembly...");
            Console.WriteLine($"{AProtectedMethod()}");
//            Console.WriteLine($"{AnInternalMethod()}");
            Console.WriteLine($"{AProtectedInternalMethod()}");
//            Console.WriteLine($"{APrivateProtectedMethod()}");
        }
        #endregion
    }

    public class Sphere // Not a 2D shape!
    {
        #region Testing Access Modifiers
        public void TestAccessModifiers()
        {
            // Let's start with a Circle!  :)
            Circle aCircle = new Circle(5);
            var area = aCircle.CalculateArea(); // I can call a public method
            Console.WriteLine();
            Console.WriteLine("Testing Access Modifiers from another assembly - not derived...");
            //Console.WriteLine($"{aCircle.AProtectedMethod()}");
            //Console.WriteLine($"{aCircle.AnInternalMethod()}");
            //Console.WriteLine($"{aCircle.AProtectedInternalMethod()}");
            //Console.WriteLine($"{aCircle.APrivateProtectedMethod()}");
        }
        #endregion
    }
}
