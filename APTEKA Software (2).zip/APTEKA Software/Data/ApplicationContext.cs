﻿using System;
using System.Collections.Generic;
using APTEKA_Software.Models;
using Microsoft.EntityFrameworkCore;

namespace APTEKA_Software.Data
{
    public class ApplicationContext : DbContext
    {
        public ApplicationContext(DbContextOptions<ApplicationContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Item> Items { get; set; }
        public DbSet<Sale> Sale { get; set; }
        public DbSet<Delivery> Deliveries { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Sales)
                .WithOne(s => s.User)
                .HasForeignKey(s => s.UserId);

            modelBuilder.Entity<User>()
                .HasMany(u => u.Deliveries)
                .WithOne(d => d.User)
                .HasForeignKey(d => d.UserId);

            modelBuilder.Entity<User>().ToTable("Users");

            modelBuilder.Entity<Item>().ToTable("Items");
            modelBuilder.Entity<Item>()
                .Property(i => i.SalePrice)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Sale>().ToTable("Sales");
            modelBuilder.Entity<Sale>()
                .Property(s => s.TotalAmount)
                .HasColumnType("decimal(18,2)");

            modelBuilder.Entity<Delivery>().ToTable("Deliveries");
            modelBuilder.Entity<Delivery>()
                .Property(d => d.TotalAmount)
                .HasColumnType("decimal(18,2)");

            var createdAt = new DateTime(2024, 01, 15, 12, 0, 0, DateTimeKind.Utc);
            var itemCreatedAt = new DateTime(2024, 01, 16, 9, 30, 0, DateTimeKind.Utc);
            var saleDate1 = new DateTime(2024, 02, 01, 10, 0, 0, DateTimeKind.Utc);
            var saleDate2 = new DateTime(2024, 02, 02, 11, 15, 0, DateTimeKind.Utc);
            var saleDate3 = new DateTime(2024, 02, 03, 14, 45, 0, DateTimeKind.Utc);
            var deliveryDate1 = new DateTime(2024, 01, 20, 8, 15, 0, DateTimeKind.Utc);
            var deliveryDate2 = new DateTime(2024, 01, 21, 13, 0, 0, DateTimeKind.Utc);
            var deliveryDate3 = new DateTime(2024, 01, 22, 16, 30, 0, DateTimeKind.Utc);

            var users = new List<User>
            {
                new User
                {
                    UserId = 1,
                    Username = "pesho",
                    Password = "123456",
                    FirstName = "Peter",
                    LastName = "Kompotov",
                    DateRegistered = createdAt,
                    IsAdmin = true
                },
                new User
                {
                    UserId = 2,
                    Username = "gosho",
                    Password = "222333",
                    FirstName = "George",
                    LastName = "Paprikov",
                    DateRegistered = createdAt,
                    IsAdmin = false
                },
                new User
                {
                    UserId = 3,
                    Username = "vanio",
                    Password = "432432",
                    FirstName = "Ivan",
                    LastName = "Krushov",
                    DateRegistered = createdAt,
                    IsAdmin = false
                },
                new User
                {
                    UserId = 4,
                    Username = "sashko",
                    Password = "654321",
                    FirstName = "Alexander",
                    LastName = "Slivov",
                    DateRegistered = createdAt,
                    IsAdmin = false
                },
            };
            modelBuilder.Entity<User>().HasData(users);

            var items = new List<Item>
            {
                new Item
                {
                    ItemId = 1,
                    AvailableQuantity = 10,
                    ItemName = "Валидол",
                    SalePrice = 5m,
                    DateCreated = itemCreatedAt
                },
                new Item
                {
                    ItemId = 2,
                    AvailableQuantity = 20,
                    ItemName = "NoSpa",
                    SalePrice = 10m,
                    DateCreated = itemCreatedAt
                },
                new Item
                {
                    ItemId = 3,
                    AvailableQuantity = 50,
                    ItemName = "Vitamin C",
                    SalePrice = 2m,
                    DateCreated = itemCreatedAt
                },
                new Item
                {
                    ItemId = 4,
                    AvailableQuantity = 42,
                    ItemName = "Vitamin D",
                    SalePrice = 6m,
                    DateCreated = itemCreatedAt
                }
            };
            modelBuilder.Entity<Item>().HasData(items);

            var sales = new List<Sale>
            {
                new Sale
                {
                    SaleId = 1,
                    ItemId = 1,
                    UserId = 1,
                    SaleDate = saleDate1,
                    QuantitySold = 3,
                    TotalAmount = 15m
                },
                new Sale
                {
                    SaleId = 2,
                    ItemId = 2,
                    UserId = 2,
                    SaleDate = saleDate2,
                    QuantitySold = 2,
                    TotalAmount = 20m
                },
                new Sale
                {
                    SaleId = 3,
                    ItemId = 3,
                    UserId = 3,
                    SaleDate = saleDate3,
                    QuantitySold = 2,
                    TotalAmount = 4m
                },
            };
            modelBuilder.Entity<Sale>().HasData(sales);

            var deliveries = new List<Delivery>
            {
                new Delivery
                {
                    DeliveryId = 1,
                    UserId = 1,
                    ItemId = 1,
                    QuantityDelivered = 15,
                    DeliveryDate = deliveryDate1,
                    TotalAmount = 75m
                },
                new Delivery
                {
                    DeliveryId = 2,
                    ItemId = 2,
                    UserId = 2,
                    QuantityDelivered = 11,
                    DeliveryDate = deliveryDate2,
                    TotalAmount = 110m
                },
                new Delivery
                {
                    DeliveryId = 3,
                    ItemId = 3,
                    UserId = 3,
                    QuantityDelivered = 30,
                    DeliveryDate = deliveryDate3,
                    TotalAmount = 60m
                },
            };
            modelBuilder.Entity<Delivery>().HasData(deliveries);
        }
    }
}
