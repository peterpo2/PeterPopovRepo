﻿namespace APTEKA_Software.Models.Dto
{
    public class UserResponseDto
    {
        public string Username { get; set; }
        public DateTime DateRegistered { get; set; }
    }
}
