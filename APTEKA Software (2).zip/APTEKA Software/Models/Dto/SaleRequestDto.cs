﻿namespace APTEKA_Software.Models.Dto
{
    public class SaleRequestDto
    {
        public int UserId { get; set; }
        public int ItemId { get; set; }
        public int QuantitySold { get; set; }
    }
}
