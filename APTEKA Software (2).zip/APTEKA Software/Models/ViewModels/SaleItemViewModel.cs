﻿namespace APTEKA_Software.Models.ViewModels
{
    public class SaleItemViewModel
    {
        public string ItemName { get; set; }
        public int Quantity { get; set; }
        public decimal SalePrice { get; set; }
        public decimal TotalPrice { get; set; }
    }
}
