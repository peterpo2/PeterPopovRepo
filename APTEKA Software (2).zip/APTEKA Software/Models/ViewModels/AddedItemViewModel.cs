﻿namespace APTEKA_Software.Models.ViewModels
{
    public class AddedItemViewModel
    {
        public int ItemId { get; set; }
        public int QuantitySold { get; set; }
    }
}
