﻿using System.Diagnostics.CodeAnalysis;

namespace CTPAXOTHAShapes
{
    public interface IShape2D
    {
        string Description { get; }
        int Dimension1 { get; set; }
        int Dimension2 { get; set; }

        double CalculateArea();
    }
}