﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace CTPAXOTHAShapes
{
    public abstract class Shape2D : IEquatable<Shape2D>, IShape2D
    {
        #region Fields
        private int dimension1 = 1;
        public int Dimension1
        {
            get { return dimension1; }
            set { dimension1 = value; }
        }
        private int dimension2 = 1;

        public int Dimension2
        {
            get { return dimension2; }
            set { dimension2 = value; }
        }
        protected string description;

        public string Description
        {
            get { return description; }
        }
        #endregion

        public Shape2D(int dim1, int dim2)
        {
            this.Dimension1 = dim1;
            this.Dimension2 = dim2;
            this.description = "Generic 2D Shape";
        }

        public virtual double CalculateArea()
        {
            return this.dimension1 * this.Dimension2;
        }

        public bool Equals([AllowNull] Shape2D other)
        {
            return this.CalculateArea() == other.CalculateArea();
        }

        #region Operator Overloading
        //public static bool operator ==(Shape2D shapeLeft, Shape2D shapeRight)
        //{
        //    if (shapeLeft.Equals(shapeRight))
        //        return true;
        //    else
        //        return false;
        //}
        //public static bool operator !=(Shape2D shapeLeft, Shape2D shapeRight)
        //{
        //    if (shapeLeft.Equals(shapeRight))
        //        return false;
        //    else
        //        return true;
        //}
        #endregion
    }

    public class Rectangle : Shape2D
    {
        public Rectangle(int width, int height) : base(width, height)
        {
            this.description = "Rectangle";
        }
    }

    public class Square : Rectangle
    {
        public Square(int length) : base(length, length)
        {
            this.description = "Square";
        }
    }

    public class Circle : Shape2D
    {
        public Circle(int radius) : base(radius, radius)
        {
            this.description = "Circle";
        }

        public override double CalculateArea()
        {
            return Math.PI * base.CalculateArea();
        }

    }

    public class Triangle : Shape2D
    {
        public Triangle(int b, int height) : base(b, height)
        {
            this.description = "Triangle";
        }
        public override double CalculateArea()
        {
            return base.CalculateArea() * 0.5;
        }

        public double CalculateArea(int a, int b, int c)
        {
            // Example of method overloading - not that "override" not required
            // Overload = different signature = method name + number of parameters + types of parameters
            // Calculage the area of a triangle using Heron's formula
            var area = 0.25 * Math.Sqrt((a + b + c) * (-a + b + c) * (a - b + c) * (a + b - c));
            return area;
        }
    }
}
