﻿using System;
using System.Collections.Generic;

namespace CTPAXOTHAShapes
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //var myShape = new Shape2D(5, 5);
            //Console.WriteLine(myShape.CalculateArea());

            //var myRectangle = new Rectangle(4, 6);
            //Console.WriteLine(myRectangle.Description + " has an area of " + myRectangle.CalculateArea());

            //var mySquare = new Square(3);
            //Console.WriteLine(mySquare.Description + " has an area of " + mySquare.CalculateArea());

            //var myCircle = new Circle(1);
            //Console.WriteLine(myCircle.Description + " has an area of " + myCircle.CalculateArea());

            #region Comparing Circles
            Console.WriteLine();
            Console.WriteLine("Comparing Circle Objects:");
            Console.WriteLine();

            Circle myCircle1 = new Circle(1);
            Circle myCircle2 = new Circle(5);
            Circle myCircle3 = new Circle(5);

            Console.WriteLine($"The area of a circle with radius {myCircle1.Dimension1} is {myCircle1.CalculateArea()}");

            // Compare circle 2 and 3 equality
            Console.WriteLine();
            Console.WriteLine("Test using == operator...");
            if (myCircle2 == myCircle3)
            {
                Console.WriteLine("Circle2 and Circle3 are equal!");
            }
            else
            {
                //Note they are different because == uses object.ReferenceEquals
                Console.WriteLine("Circle2 and Circle3 are different!");
            }

            Console.WriteLine();
            Console.WriteLine("Test using object.Equals method...");
            if (myCircle2.Equals(myCircle3))
            {
                Console.WriteLine("Circle2 and Circle3 are equal!");
            }
            else
            {
                Console.WriteLine("Circle2 and Circle3 are different!");
            }
            #endregion


            Console.WriteLine();
            Console.WriteLine("Polymorphism - different things at the same time!");
            var mySquare = new Square(1);
            var myRectangle = new Rectangle(5, 3);
            if (mySquare is Square)
            {
                Console.WriteLine($"{mySquare.ToString()} is a type of Square! (derived class)");
            }
            if (mySquare is Rectangle)
            {
                Console.WriteLine($"{mySquare.ToString()} IS A Rectangle! (inheritance)");
            }
            if (mySquare is Shape2D)
            {
                Console.WriteLine($"{mySquare.ToString()} IS A Shape2D! (inheritance)");
            }
            if (!(mySquare is Circle))
            {
                Console.WriteLine($"{mySquare.ToString()} IS NOT A Circle!");
            }

            var myShapes = new List<Shape2D>();
            myShapes.Add(myCircle1);
            myShapes.Add(myCircle2);
            myShapes.Add(myCircle3);
            myShapes.Add(new Rectangle(5, 5));
            myShapes.Add(new Square(6));
            myShapes.Add(new Triangle(3, 4));

            Console.WriteLine();
            Console.WriteLine("This means we can operate on Shapes generically...");
            foreach (Shape2D shape in myShapes)
            {
                Console.WriteLine(shape.Description + " of area " + shape.CalculateArea());
            }



            Console.WriteLine();
            Console.WriteLine("Press any key to continue....");
            Console.ReadKey();
        }
    }
}
